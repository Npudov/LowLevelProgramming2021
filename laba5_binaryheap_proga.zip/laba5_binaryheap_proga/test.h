//
// Created by Nikita on 12.05.2021.
//

#ifndef LABA5_BINARYHEAP_PROGA_TEST_H
#define LABA5_BINARYHEAP_PROGA_TEST_H
void addTest();
#endif //LABA5_BINARYHEAP_PROGA_TEST_H
